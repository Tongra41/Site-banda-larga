
function abrirChat() {
  const chat = document.getElementById("chat");
  chat.style.display = chat.style.display === "block" ? "none" : "block";
}
